package com;

interface a{
	void show();
}
interface b{
	void show();
}
interface c extends a,b{
	void display();
}


class Test implements a,b,c {
	@Override
	public void display() {
		
		System.out.println("hello");
	}
	@Override
	public void show() {
	System.out.println("hi");		
	}

}
public class MultipleInheritanceDemo {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Test t= new Test();
		t.display();
		t.show();	
	}
}
