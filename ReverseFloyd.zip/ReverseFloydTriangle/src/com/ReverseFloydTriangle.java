package com;

import java.util.Scanner;

public class ReverseFloydTriangle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the Number of row for Triangle ");
		int i=s.nextInt();
		for (int j=i;j>0;i--){
			for(int k=0;k<j;k++){
				System.out.print("*");
			}
			System.out.println();
		}

	}

}
