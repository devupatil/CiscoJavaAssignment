package com;

import java.util.Scanner;

public class WeekName {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		for(;;){
			System.out.println("Enter number to get Week name..?");
			int i=s.nextInt();
			switch(i){
			case 1:System.out.println("Moday");
					break;
			case 2:System.out.println("Tuesday");
					break;
			case 3:System.out.println("Wednesday");
					break;
			case 4:System.out.println("Thursday");
					break;
			case 5:System.out.println("Friday");
					break;
			case 6:System.out.println("Saturday");
					break;
			case 7:System.out.println("");
					break;
			default:continue;
					
			}
		}
	}

}
