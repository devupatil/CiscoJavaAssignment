package com;

class MethodOverridding {
	public void multiple(int a, int b){
		System.out.println("Multiplication in super class "+a*b);
	}
	
}
class MethodOverridding1 extends MethodOverridding{
	public void multiple(int a,int b){
		System.out.println("Multiplication in sub class "+a*b);
	}
}
