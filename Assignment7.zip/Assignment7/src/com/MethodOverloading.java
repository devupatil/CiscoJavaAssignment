package com;

public class MethodOverloading {
	public void sum(int a,int b){
		System.out.println("sum is "+ a+b);
	}
	void   sum(int a,int b,int c){
		System.out.println("sum is "+a+b+c);
	}
	
}
