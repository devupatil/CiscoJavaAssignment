package com;

public class Tester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MethodOverloading ml=new MethodOverloading();
		MethodOverridding mr=new MethodOverridding1();
		ml.sum(12, 23, 12);
		mr.multiple(12, 3423);
	}

}
