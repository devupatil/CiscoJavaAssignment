package com;
class Box {

	int width;

	int height;

	int depth;
        ///{Write your code here 
    public Box(int width,int height, int depth){
    	this.width=width;
    	this.height=height;
    	this.depth=depth;
    }
    public Box(int length){
    	this.depth=length;
    	this.height=length;
    	this.width=length;
    }
    public Box(){
    	width=-1;
    	height=-1;
    	depth=-1;
    }
 
        ///} 

	int volume() {

		return width * height * depth;

	}

}

class ConsuctorOverloadingDemo {

	public static void main(String args[]) {

		Box mybox1 = new Box(10, 20, 15);

		Box mybox2 = new Box();

		Box mycube = new Box(7);

		int vol;

		vol = mybox1.volume();

		System.out.println("Volume of mybox1 is " + vol);

		vol = mybox2.volume();

		System.out.println("Volume of mybox2 is " + vol);

		vol = mycube.volume();

		System.out.println("Volume of mycube is " + vol);
	}
}

